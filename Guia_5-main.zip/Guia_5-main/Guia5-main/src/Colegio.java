import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

/*
 4. Crea una clase colegio que almacene el listado de los alumnos (compuestos
        por su nombre y nacionalidad). La clase tendrá los siguientes
        métodos:
        - agregarAlumno(Alumno alumno): añade el alumno recibido por
        parámetro al listado.
        - verNacionalidad(String nacionalidad): Muestra la nacionalidad y el
        número de alumnos de esa nacionalidad
        - cuantos(): Muestra cuántas nacionalidades diferentes existen en el
        colegio.
        - borrar(Alumno alumno): Elimina a un alumno específico del listado.
        - verTodos(): Muestra las distintas nacionalidades y el número de
        alumnos que existen por nacionalidad.
        Para todos estos métodos se deben generar distintas validaciones para
        prevenir errores en la ejecución. Por ej: Que todos los alumnos tengan una
        nacionalidad, que exista el alumno que se quiere borrar, etc.
 */

public class Colegio {

    private List<Alumno> alumnos;

    public Colegio(){
        alumnos = new ArrayList<>();
    }

    public void agregarAlumno(Alumno alumno){
        if(alumno==null){
            throw new IllegalArgumentException("El alumno no puede ser nulo.");
        }
        try{
            alumnos.add(alumno);
        }catch(Exception e){
            throw new RuntimeException();
        }
    }

    public String verNacionalidad(String nacionalidad){
        String retorno="";
        int contador=0;
        try{
            for(Alumno alumno : alumnos){
                if(alumno.getNacionalidad().equals(nacionalidad)){
                    contador++;
                }
            }
            retorno="Se encontraron " + contador + " alumnos de nacionalidad " + nacionalidad;
        }catch(InputMismatchException e){
            retorno="Error: debe ingresar una cadena de texto. Inténtelo nuevamente.";
        }
        return retorno;
    }

}

public class Alumno {
    private String nombre;
    private String nacionalidad;
}
